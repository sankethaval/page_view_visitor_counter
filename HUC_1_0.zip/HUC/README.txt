READ ME:
*********

This software is developed and copyrighted by HIOX Softwares.
This is given under The GNU General Public License (GPL).
This version is HUC 1.0


Features:
=========
a) Web visitor counter that counts the unique visitors for a web page.
b) This visitor counter counts only unique visitors based on the visitor's ip-address.
c) This unique visitor script works based on date or day. The visit from an ip-address to a web page will be counted only once every day or date.
d) For example if a visitor visits the page on the 23rd hour of a day and again on the 2nd hour of next day it is treated as 2 different unique visitors.
d) Initial or starting visitor count or the total visitor count can be set by setting the value in the Get Code page.
e) Easy to use.


Installation:
Please take 5 minutes time and read installation instructions carefully and
completely! This will ensure a proper and easy installation.

a) Unzip HUC.zip. to extract the files to a  folder \HUC_1_0\HUC

File Permissions:
   a) Set read write permissions (666) for count.txt and passwo.php (For Linux
Users).
   
Creating username and password:
  a) Open the file about.php in a browser
  b) Click on “Change Password” to create a new user name, password

Embedding Unique  counter:
 a) Click on the menu “Get code”
 b) Click on “Select all” to copy the code
 c)  Insert the code in any web page to get the counter
 d) Change your file name as .php (e.g: index.html to index.php).

Setting the counter Value:
 a) Click on the menu “Get code”
 b) Provide the starting value of the counter
 c) Click on “Ok”

Reporting:
  If you have any issues with the code, please, click on the option “Report” to
go to feedback page of Hscripts.com to give feedback

What you can do for us:
  If you use HIOX Software’s free scripts or any portion of the code, a link to
Hscripts.com will be on your website. We believe it is a fair trade for a free
script/code. Please don’t remove the link. It will of great help to us.


Releases:
=========
Release Date HUC 1.0 : 20-04-2004

On any suggestions mail to us at support@hscripts.com
For detailed License information can be found in
http://hscripts.com/license/hioxlicense.html

Visit us at http://www.hscripts.com
Visit us at http://www.hioxindia.com
